# @zjqx/gridfield OpenLayers 版本

这是 ZJQX 气象格点渲染包的 OpenLayers-only 版本。它保留原来的业务入口名，同时将底层地图运行时切换为 OpenLayers。

- `ZJQXMap` 是 `ZJQXOpenLayersMap` 的别名。
- `ZJQXGridFieldLayer` 是 `ZJQXOpenLayersGridFieldLayer` 的别名。
- 格点图层使用 OpenLayers `ImageCanvas` 渲染，不再依赖 Leaflet pane / DOM overlay transform。
- 当前源码包已移除 Leaflet 示例和 Leaflet 依赖。

## 快速启动

```bash
npm install
npm run dev
```

访问根页面：

```txt
http://localhost:5173/
```

## 示例目录

| 示例 | 地址 | 说明 |
| --- | --- | --- |
| 色斑图 | `/examples/01-color-fill/` | 格点填色、色标、裁剪、边界、数值文本 |
| 等值线 | `/examples/02-contour/` | 色斑背景、等值线、等值线标注、格点文本切换 |
| 风场 | `/examples/03-wind/` | 风速色斑、风杆图、风速文字、v/d 风速风向字段 |
| PBF | `/examples/04-pbf/` | `metadata.json + chunks/*.pbf` 拼接为 Grid2D 后渲染 |

## 最小用法

```ts
import 'ol/ol.css';
import {
  ZJQXMap,
  ZJQXGridFieldLayer,
  normalizeWeatherGrid,
  createColorScale,
  createPaletteTextureData,
} from '@zjqx/gridfield';

const map = ZJQXMap.initMap('map', {
  center: [29.5, 120.2],
  zoom: 7,
  baseLayer: {
    url: 'https://tile.openstreetmap.org/{z}/{x}/{y}.png',
    sourceOptions: { crossOrigin: 'anonymous' },
    layerOptions: { preload: 3 },
  },
});

const grid = normalizeWeatherGrid(rawGrid, { rowOrder: 'south-to-north' });
const colorize = createColorScale(colorConfig, { mode: 'step', stopKey: 'stops' });
const palette = createPaletteTextureData(colorConfig, { mode: 'step', stopKey: 'stops' });

const layer = new ZJQXGridFieldLayer({
  data: grid,
  colorize,
  palette,
  fill: { enabled: true, fillType: 2, opacity: 0.94 },
  renderResolutionMode: 'integer-zoom',
  interpolate: true,
  ratio: 1.15,
});

map.addZJQXLayer(layer);
map.fitBounds([[grid.south, grid.west], [grid.north, grid.east]], 72);
```

## OpenLayers 坐标约定

为了减少业务代码迁移成本，`ZJQXMap` 对外仍然使用 `[lat, lng]`：

```ts
center: [29.5, 120.2]
map.fitBounds([[south, west], [north, east]], 72)
```

内部会转换为 OpenLayers 使用的 `[lng, lat]` / EPSG:3857 坐标。

## 渲染建议

默认推荐：

```ts
renderResolutionMode: 'integer-zoom',
interpolate: true,
ratio: 1.15,
```

含义：

- `integer-zoom`：按整数 zoom 缓存画布，缩放动画期间由 OpenLayers 统一做连续图像变换。
- `interpolate: true`：OpenLayers 对缓存图像缩放时插值，动画更顺滑。
- `ratio: 1.15`：ImageCanvas 多渲染一圈，减少平移时边缘空白。

如果你追求每个缩放级别都重新计算图层，可改为：

```ts
renderResolutionMode: 'view-resolution'
```

但该模式更容易增加缩放过程中的重绘压力。

## 文档

- [`docs/EXAMPLES.md`](./docs/EXAMPLES.md)：四个示例的定位、入口和关键配置。
- [`docs/API_OPENLAYERS.md`](./docs/API_OPENLAYERS.md)：OpenLayers 版核心 API。
- [`docs/MIGRATION_OPENLAYERS.md`](./docs/MIGRATION_OPENLAYERS.md)：从 Leaflet 版本迁移到 OpenLayers 版本。
- [`docs/PBF.md`](./docs/PBF.md)：PBF 切片数据组织和加载说明。
