# @zjqx/gridfield OpenLayers 版本

这是 ZJQX 气象格点渲染包的 OpenLayers-only 版本。它保留原来的业务入口名，同时将底层地图运行时切换为 OpenLayers。

- `ZJQXMap` 是 `ZJQXOpenLayersMap` 的别名。
- `ZJQXGridFieldLayer` 是 `ZJQXOpenLayersGridFieldLayer` 的别名。
- 格点图层默认使用兼容的 OpenLayers `ImageLayer` 缓存模式；可通过地图配置启用 `WebGLTile` 空间瓦片纹理缓存与实时文本。
- 当前源码包已移除 Leaflet 示例和 Leaflet 依赖。

## 快速启动

```bash
npm install
npm run dev
```

访问根页面：

```txt
http://localhost:5173/
```

## 示例目录

| 示例 | 地址 | 说明 |
| --- | --- | --- |
| 色斑图 | `/examples/01-color-fill/` | 格点填色、色标、裁剪、边界、数值文本 |
| 等值线 | `/examples/02-contour/` | 色斑背景、等值线、等值线标注、格点文本切换 |
| 风场 | `/examples/03-wind/` | 风速色斑、风杆图、风速文字、v/d 风速风向字段 |
| PBF | `/examples/04-pbf/` | `metadata.json + chunks/*.pbf` 拼接为 Grid2D 后渲染 |

## 最小用法

```ts
import 'ol/ol.css';
import {
  ZJQXMap,
  ZJQXGridFieldLayer,
  normalizeWeatherGrid,
  createColorScale,
  createPaletteTextureData,
} from '@zjqx/gridfield';

const map = ZJQXMap.initMap('map', {
  center: [29.5, 120.2],
  zoom: 7,
  gridFieldPerformanceMode: true,
  baseLayer: {
    url: 'https://tile.openstreetmap.org/{z}/{x}/{y}.png',
    sourceOptions: { crossOrigin: 'anonymous' },
    layerOptions: { preload: 3 },
  },
});

const grid = normalizeWeatherGrid(rawGrid, { rowOrder: 'south-to-north' });
const colorize = createColorScale(colorConfig, { mode: 'step', stopKey: 'stops' });
const palette = createPaletteTextureData(colorConfig, { mode: 'step', stopKey: 'stops' });

const layer = new ZJQXGridFieldLayer({
  data: grid,
  colorize,
  palette,
  fill: { enabled: true, fillType: 2, opacity: 0.94 },
  interpolate: true,
});

map.addZJQXLayer(layer);
map.fitBounds([[grid.south, grid.west], [grid.north, grid.east]], 72);
```

## OpenLayers 坐标约定

为了减少业务代码迁移成本，`ZJQXMap` 对外仍然使用 `[lat, lng]`：

```ts
center: [29.5, 120.2]
map.fitBounds([[south, west], [north, east]], 72)
```

内部会转换为 OpenLayers 使用的 `[lng, lat]` / EPSG:3857 坐标。

## 渲染建议

`gridFieldPerformanceMode` 默认为 `false`，底图和文本都使用旧的 `ImageLayer` 缓存画布。需要启用空间 GPU 瓦片优化时，在 `ZJQXMap` 上配置：

```ts
const map = ZJQXMap.initMap('map', {
  center: [29.5, 120.2],
  zoom: 7,
  gridFieldPerformanceMode: true,
});
```

含义：

- `false`：底图与文本使用 `ImageLayer`，缩放动画期间拉伸旧 Canvas，交互结束后请求新画布。
- `true`：底图按 Web Mercator 空间瓦片生成并进入 WebGL 纹理缓存，文本按当前帧实时绘制。
- 低性能模式会强制文本使用 `ImageLayer`；高性能模式下可用 `stableLabelsDuringZoom: false` 单独让文本降级。`baseRenderMode` 可覆盖底图模式，`gpuTiles` 用于调整高性能瓦片参数。

如需为单个图层强制使用整屏逐帧绘制，可配置：

```ts
baseRenderMode: 'live-canvas'
```

该模式会显著增加缩放过程中的整屏重绘压力。旧的 `renderResolutionMode` 和 `ratio` 仅在 `baseRenderMode: 'image-canvas'` 时生效。

## 文档

- [`docs/EXAMPLES.md`](./docs/EXAMPLES.md)：四个示例的定位、入口和关键配置。
- [`docs/API_OPENLAYERS.md`](./docs/API_OPENLAYERS.md)：OpenLayers 版核心 API。
- [`docs/MIGRATION_OPENLAYERS.md`](./docs/MIGRATION_OPENLAYERS.md)：从 Leaflet 版本迁移到 OpenLayers 版本。
- [`docs/PBF.md`](./docs/PBF.md)：PBF 切片数据组织和加载说明。


## 三种接入方式

当前包已支持三种使用方式：

1. npm / ESM：`import { ZJQXMap } from '@zjqx/gridfield/map'`；
2. 浏览器全量 UMD：`<script src="/sdk/0.2.3/zjqx-gridfield.umd.js"></script>`；
3. URL Loader 按模块加载：`<script src="/sdk/0.2.3/zjqx-loader.js?modules=map,grid,legend"></script>`。

详细说明见 `docs/SDK_THREE_USAGE.md`。
